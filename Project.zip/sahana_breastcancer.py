import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from sklearn import metrics

url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer/breast-cancer.data'
names = ['Class', 'age', 'menopause', 'tumor-size', 'inv-nodes', 'node-caps', 'deg-malig', 'breast', 'breast-quad', 'irradiat'] 
df=pd.read_csv(url, names=names)

le = LabelEncoder()
df['age'] = le.fit_transform(df['age'])
df['menopause'] = le.fit_transform(df['menopause'])
df['tumor-size'] = le.fit_transform(df['tumor-size'])
df['node-caps'] = le.fit_transform(df['node-caps'])
df['breast'] = le.fit_transform(df['breast'])
df['breast-quad'] = le.fit_transform(df['breast-quad'])
df['irradiat'] = le.fit_transform(df['irradiat'])
df['inv-nodes'] = le.fit_transform(df['inv-nodes'])

df.dropna(inplace = True)

d = {'recurrence-events': 1, 'no-recurrence-events': 0}
df['Class'] = df['Class'].map(d)

X = df.drop('Class', axis=1)
y = df['Class']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# Fit logistic regression classifier
lr = LogisticRegression()
lr.fit(X_train, y_train)
lr_pred = lr.predict(X_test)
lr_accuracy = metrics.accuracy_score(y_test, lr_pred)
lr_precision = metrics.precision_score(y_test, lr_pred)
lr_sensitivity_recall = metrics.recall_score(y_test, lr_pred)
lr_specificity = metrics.recall_score(y_test, lr_pred, pos_label=0)
lr_F1_score = metrics.f1_score(y_test, lr_pred)


# Fit KNN classifier
knn = KNeighborsClassifier()
knn.fit(X_train, y_train)
knn_pred = knn.predict(X_test)
knn_accuracy = metrics.accuracy_score(y_test, knn_pred)
knn_precision = metrics.precision_score(y_test, knn_pred)
knn_sensitivity_recall = metrics.recall_score(y_test, knn_pred)
knn_specificity = metrics.recall_score(y_test, knn_pred, pos_label=0)
knn_F1_score = metrics.f1_score(y_test, knn_pred)


# Fit Naive Bayes classifier
nb = GaussianNB()
nb.fit(X_train, y_train)
nb_pred = nb.predict(X_test)
nb_accuracy = metrics.accuracy_score(y_test, nb_pred)
nb_precision = metrics.precision_score(y_test, nb_pred)
nb_sensitivity_recall = metrics.recall_score(y_test, nb_pred)
nb_specificity = metrics.recall_score(y_test, nb_pred, pos_label=0)
nb_F1_score = metrics.f1_score(y_test, nb_pred)

#confusion matrix
cm_lr = metrics.confusion_matrix(y_test, lr_pred)
cm_knn = metrics.confusion_matrix(y_test, knn_pred)
cm_nb = metrics.confusion_matrix(y_test, nb_pred)

cm_lr_display = metrics.ConfusionMatrixDisplay(confusion_matrix = cm_lr, display_labels = [False, True])
cm_lr_display.plot()
plt.show()

cm_knn_display = metrics.ConfusionMatrixDisplay(confusion_matrix = cm_knn, display_labels = [False, True])
cm_knn_display.plot()
plt.show()

cm_nb_display = metrics.ConfusionMatrixDisplay(confusion_matrix = cm_nb, display_labels = [False, True])
cm_nb_display.plot()
plt.show()

cm = {
    'Model': ['Logistic Regression', 'K-Nearest Neighbors', 'Naive Bayes'],
    'True Positive': [cm_lr[0][0], cm_knn[0][0], cm_nb[0][0]],
    'False Positive': [cm_lr[0][1], cm_knn[0][1], cm_nb[0][1]],
    'True Negative': [cm_lr[1][1], cm_knn[1][1], cm_nb[1][1]],
    'False Negative': [cm_lr[1][0], cm_knn[1][0], cm_nb[1][0]],
}
df_cm = pd.DataFrame.from_dict(cm)
df_cm.to_csv("Confusion_matrix.csv")
print('Confusion Matrix:\n ',df_cm.to_string())


#saving results
results = {
    'Model': ['Logistic Regression', 'K-Nearest Neighbors', 'Naive Bayes'],
    "Accuracy" : [lr_accuracy, knn_accuracy, nb_accuracy],
    "Precision": [lr_precision, knn_precision, nb_precision],
    "Sensitivity": [lr_sensitivity_recall, knn_sensitivity_recall, nb_sensitivity_recall],
    "Specificity": [lr_specificity, knn_specificity, nb_specificity],
    "F1_score": [lr_F1_score, knn_F1_score, nb_F1_score]}

df_results = pd.DataFrame.from_dict(results)
df_results.to_csv('Results.csv')
print('Results:\n ',df_results.to_string())




