import requests
from bs4 import BeautifulSoup
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

url = 'https://monkeylearn.com/sentiment-analysis/'

response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

text = ''
for paragraph in soup.find_all('p'):
    text += paragraph.get_text()

nltk.download('vader_lexicon')
sia = SentimentIntensityAnalyzer()
sentiment = sia.polarity_scores(text)

print("Text:\n ", text)

print("Sentiment:",end = ' ')
if sentiment['compound'] > 0:
    print('Positive')
elif sentiment['compound'] < 0:
    print('Negative')
else:
    print('Neutral')